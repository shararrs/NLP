How to run:
1) Launch `1_web_crawler.py` to crawl & download website text
2) Launch `2_top_term_finder.py` to extract sentences and top terms from the raw files. The top terms will be output to the display
3) Launch `3_kb_creator.py` to create the knowledge base file. It will ask you to input the top 10 terms from the output of program 2.
4) Laucnh `4_kb_searcher.py` to query the knowledge base.

These programs must be executed in order on the first usage.